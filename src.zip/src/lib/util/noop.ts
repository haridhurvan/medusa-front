/**
 * A funtion that does nothing.
 */
const noop = () => {}

export default noop
