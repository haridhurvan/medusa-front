import SkeletonProductPage from "@modules/skeletons/templates/skeleton-product-page"

export default function Loading() {
  return <SkeletonProductPage />
}
